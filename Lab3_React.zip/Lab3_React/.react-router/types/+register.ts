import "react-router";

declare module "react-router" {
  interface Register {
    params: Params;
  }
}

type Params = {
  "/": {};
  "/new": {};
  "/edit/:id": {
    "id": string;
  };
  "/login": {};
  "/cart": {};
};