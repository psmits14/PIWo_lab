import React, { createContext, useReducer } from 'react';

const initState = [];

const reduce = (state, action) => {
  switch (action.type) {
    case "ADD_ITEM":
      return [...state, action.payload];

    case "REMOVE_ITEM":
      return state.filter(it => it.id !== action.payload.id);

    default:
      return state;
  }
};


const InProgressContext = createContext();

export const InProgressProvider = ({ children }) => {
  
    const [state, dispatch] = useReducer(reduce, initState);

    return (
        <InProgressContext.Provider value={{ state, dispatch }}>
        {children}
        </InProgressContext.Provider>
    );
};

export default InProgressContext;