export default function Footer() {
  return (
    <footer>
      &copy; 2025 Księgarnia Między Kartkami | Wszystkie prawa zastrzeżone
    </footer>
  );
}
