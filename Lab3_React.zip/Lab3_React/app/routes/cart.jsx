import React, { useContext } from "react";
import InProgressContext from "../Contexts/inProgressContext";

const Cart = () => {
  const { state } = useContext(InProgressContext);

  return (
    <div className="container">
      <h1>Koszyk</h1>
      {state.length === 0 ? (
        <p>Twój koszyk jest pusty.</p>
      ) : (
        <ul>
          {state.map((item) => (
            <li key={item.id}>
              {item.title} — {item.author}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Cart;
